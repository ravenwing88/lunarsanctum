To Hell in a Handbasket v1.0.2by Nemesis*CONTACT INFO*E-Mail: scduffy488@gmail.comHomepage: https://ravenwing88.github.io/lunarsanctum/Spiderweb Software Message Boards: Nemesis

o====}====================>

*WALKTHROUGH*

Hell:
You're dead. It's Hell. You can't escape. The end.

o====}====================>

*HINTS, TIPS, AND SECRETS*
(Warning: May contain spoilers)

Hell:
-Okay, so there's a special ability that'll whisk you out. But you're not supposed to use it. So... don't.

o====}====================>

*INCLUDED FILES*

If these files are not present, the scenario will not work properly and must be downloaded again.

Mac Only:
-2HaH.cmg

All:
-2HaH.bas
-2HaH.txt
-basicnpc.txt
-door.txt
-guard.txt
-README.txt
-specobj.txt
-t0hell.txt
-trap.txt

o====}====================>*CREDITS/ACKNOWLEDGEMENTS*Special Thanks:-Niemand, for the initial inspiration of randomized landscape.
-Nikki, for the idea to make the party invulnerable.-All the Spiderwebbers. I promise I'll start work on real scenarios again.-The folks at Spiderweb, for reasons that ought to be obvious.-Anyone who downloads and plays this rubbish. I apologize for any kind of excited you got when I said I was releasing a new scenario.o====}====================>*VERSION HISTORY*v1.0.0 - 4/4/10 - Initial release
v1.0.1 - 4/5/10
	-Made the party invulnerable. Now they must suffer without death for eternity!
	-Set the hordling levels to 1. Why should they be more than an annoyance?
	-Changed the random fire damage; can no longer kill characters.
	-Made the suggested level 1-100. Not that it matters, really.v1.0.2 - 11/15/24	-Removed the custom graphics from the PC version. Apparently they don't work at all.